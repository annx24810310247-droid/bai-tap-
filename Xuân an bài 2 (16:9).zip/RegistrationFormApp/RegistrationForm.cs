using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace WinFormsApp
{
    public class Course
    {
        public string CourseId { get; set; }
        public string CourseName { get; set; }

        public Course(string id, string name)
        {
            CourseId = id;
            CourseName = name;
        }
    }

    public class RegistrationForm : Form
    {
        private MaskedTextBox mtxtPhone;
        private DateTimePicker dtpBirthDate;
        private ComboBox cboCourse;
        private RadioButton rdoMale;
        private RadioButton rdoFemale;
        private CheckBox chkAgree;
        private Button btnRegister;

        public RegistrationForm()
        {
            InitializeComponents();
            BindCourseData();
        }

        private void InitializeComponents()
        {
            this.Text = "Đăng Ký Khóa Học";
            this.Size = new Size(420, 360);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            Label lblPhone = new Label { Text = "Số điện thoại:", Top = 25, Left = 20, AutoSize = true };
            mtxtPhone = new MaskedTextBox
            {
                Mask = "(000) 000-0000",
                Top = 22,
                Left = 140,
                Width = 220
            };

            Label lblBirthDate = new Label { Text = "Ngày sinh:", Top = 65, Left = 20, AutoSize = true };
            dtpBirthDate = new DateTimePicker
            {
                Format = DateTimePickerFormat.Custom,
                CustomFormat = "dd/MM/yyyy",
                Top = 62,
                Left = 140,
                Width = 220
            };

            GroupBox gbGender = new GroupBox
            {
                Text = "Giới tính",
                Top = 100,
                Left = 20,
                Width = 340,
                Height = 55
            };
            rdoMale = new RadioButton { Text = "Nam", Left = 30, Top = 20, AutoSize = true, Checked = true };
            rdoFemale = new RadioButton { Text = "Nữ", Left = 150, Top = 20, AutoSize = true };
            gbGender.Controls.AddRange(new Control[] { rdoMale, rdoFemale });

            Label lblCourse = new Label { Text = "Khóa học:", Top = 175, Left = 20, AutoSize = true };
            cboCourse = new ComboBox
            {
                Top = 172,
                Left = 140,
                Width = 220,
                DropDownStyle = ComboBoxStyle.DropDownList
            };

            chkAgree = new CheckBox
            {
                Text = "Tôi đồng ý với điều khoản đăng ký",
                Top = 215,
                Left = 20,
                AutoSize = true
            };

            btnRegister = new Button
            {
                Text = "Đăng ký",
                Top = 255,
                Left = 140,
                Width = 120,
                Height = 35
            };
            btnRegister.Click += BtnRegister_Click;

            this.Controls.AddRange(new Control[] {
                lblPhone, mtxtPhone,
                lblBirthDate, dtpBirthDate,
                gbGender,
                lblCourse, cboCourse,
                chkAgree, btnRegister
            });
        }

        private void BindCourseData()
        {
            List<Course> courses = new List<Course>
            {
                new Course("CS01", "Lập trình C# WinForms"),
                new Course("NET02", "Lập trình .NET Core API"),
                new Course("WEB03", "Thiết kế Web Responsive"),
                new Course("DB04", "Quản trị cơ sở dữ liệu SQL Server")
            };

            cboCourse.DataSource = courses;
            cboCourse.DisplayMember = "CourseName";
            cboCourse.ValueMember = "CourseId";
        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {
            if (!chkAgree.Checked)
            {
                MessageBox.Show("Vui lòng tích chọn đồng ý với điều khoản trước khi đăng ký!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!mtxtPhone.MaskCompleted)
            {
                MessageBox.Show("Vui lòng nhập đầy đủ số điện thoại theo định dạng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string phone = mtxtPhone.Text;
            string birthDate = dtpBirthDate.Value.ToString("dd/MM/yyyy");
            string gender = rdoMale.Checked ? "Nam" : "Nữ";
            string selectedCourseName = cboCourse.Text;
            string selectedCourseId = cboCourse.SelectedValue?.ToString();

            string info = $"--- THÔNG TIN ĐĂNG KÝ ---\n\n" +
                          $"• Số điện thoại: {phone}\n" +
                          $"• Ngày sinh: {birthDate}\n" +
                          $"• Giới tính: {gender}\n" +
                          $"• Khóa học: {selectedCourseName}\n" +
                          $"• Mã khóa học: {selectedCourseId}\n" +
                          $"• Trạng thái điều khoản: Đã chấp nhận";

            MessageBox.Show(info, "Đăng ký thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
