# Dự án WinForms - Form Đăng Ký Khóa Học

Dự án C# Windows Forms App sử dụng các Control nâng cao: ComboBox Data Binding, MaskedTextBox, DateTimePicker, RadioButton & CheckBox.

## Cấu trúc thư mục
- `RegistrationForm.cs`: Quản lý giao diện, binding data khóa học và tổng hợp xuất thông tin.
- `Program.cs`: File khởi chạy ứng dụng.
- `RegistrationFormApp.csproj`: File dự án .NET.

## Cách chạy dự án:
1. Mở thư mục dự án trong Visual Studio / VS Code.
2. Chạy lệnh: `dotnet run`
