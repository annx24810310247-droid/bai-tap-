using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp
{
    // Class định nghĩa đối tượng Món Ăn
    public class FoodItem
    {
        public string Name { get; set; }
        public decimal Price { get; set; }

        public FoodItem(string name, decimal price)
        {
            Name = name;
            Price = price;
        }

        public override string ToString()
        {
            return $"{Name} - {Price:N0}k";
        }
    }

    public class FoodOrderForm : Form
    {
        private ListBox lstMenu;
        private ListBox lstSelected;
        private Button btnAdd;
        private Button btnRemove;
        private Label lblTotal;

        public FoodOrderForm()
        {
            InitializeComponents();
            LoadMenuData();
        }

        private void InitializeComponents()
        {
            this.Text = "Quản Lý Đặt Món Ăn";
            this.Size = new Size(520, 380);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // 1. Label Tiêu đề Danh sách
            Label lblMenuTitle = new Label { Text = "Thực Đơn (Menu)", Top = 15, Left = 20, AutoSize = true, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            Label lblSelectedTitle = new Label { Text = "Món Đã Chọn", Top = 15, Left = 280, AutoSize = true, Font = new Font("Segoe UI", 10, FontStyle.Bold) };

            // 2. ListBox Thực đơn
            lstMenu = new ListBox
            {
                Top = 45,
                Left = 20,
                Width = 200,
                Height = 220,
                SelectionMode = SelectionMode.One
            };

            // 3. ListBox Món đã chọn
            lstSelected = new ListBox
            {
                Top = 45,
                Left = 280,
                Width = 200,
                Height = 220,
                SelectionMode = SelectionMode.One
            };

            // 4. Các Nút Chuyển Món
            btnAdd = new Button
            {
                Text = ">",
                Top = 100,
                Left = 230,
                Width = 40,
                Height = 40,
                Font = new Font("Segoe UI", 12, FontStyle.Bold)
            };
            btnAdd.Click += BtnAdd_Click;

            btnRemove = new Button
            {
                Text = "<",
                Top = 150,
                Left = 230,
                Width = 40,
                Height = 40,
                Font = new Font("Segoe UI", 12, FontStyle.Bold)
            };
            btnRemove.Click += BtnRemove_Click;

            // 5. Label Hiển thị Tổng Tiền
            lblTotal = new Label
            {
                Text = "Tổng tiền: 0k",
                Top = 285,
                Left = 280,
                Width = 200,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = Color.DarkRed,
                AutoSize = true
            };

            this.Controls.AddRange(new Control[] {
                lblMenuTitle, lblSelectedTitle,
                lstMenu, lstSelected,
                btnAdd, btnRemove,
                lblTotal
            });
        }

        // Nạp dữ liệu mặc định cho Menu
        private void LoadMenuData()
        {
            List<FoodItem> menuItems = new List<FoodItem>
            {
                new FoodItem("Hamburger", 50),
                new FoodItem("Pizza", 120),
                new FoodItem("Gà Rán", 35),
                new FoodItem("Pepsi", 15)
            };

            lstMenu.DataSource = menuItems;
        }

        // Sự kiện chuyển món từ Menu sang Selected (Nút >)
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (lstMenu.SelectedItem != null)
            {
                FoodItem selectedItem = (FoodItem)lstMenu.SelectedItem;
                lstSelected.Items.Add(selectedItem);
                UpdateTotalPrice();
            }
        }

        // Sự kiện xóa món khỏi Selected (Nút <)
        private void BtnRemove_Click(object sender, EventArgs e)
        {
            if (lstSelected.SelectedItem != null)
            {
                lstSelected.Items.Remove(lstSelected.SelectedItem);
                UpdateTotalPrice();
            }
        }

        // Tính toán tổng tiền động và cập nhật Label
        private void UpdateTotalPrice()
        {
            decimal total = 0;
            foreach (FoodItem item in lstSelected.Items)
            {
                total += item.Price;
            }
            lblTotal.Text = $"Tổng tiền: {total:N0}k";
        }
    }
}
