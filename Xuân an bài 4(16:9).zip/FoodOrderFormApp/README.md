# Dự án WinForms - Quản Lý Đặt Món Ăn (Food Order Form)

Dự án C# WinForms quản lý danh sách món ăn sử dụng 2 ListBox, thực hiện chuyển đổi items bằng nút `>` / `<` và cập nhật tổng tiền động.

## Cấu trúc thư mục
- `FoodOrderForm.cs`: Quản lý giao diện, danh sách món ăn, sự kiện chuyển món và tính tổng tiền.
- `Program.cs`: Entry point khởi chạy ứng dụng.
- `FoodOrderFormApp.csproj`: File cấu hình dự án .NET.

## Cách chạy dự án:
1. Mở thư mục dự án trong Visual Studio / VS Code.
2. Chạy lệnh: `dotnet run`
