# Dự án WinForms - Form Quản Lý Chuẩn Responsive

Dự án C# WinForms thiết kế giao diện tự co giãn theo tỷ lệ khi Maximize cửa sổ, không bị vỡ giao diện.

## Cấu trúc thư mục
- `ResponsiveForm.cs`: Thiết lập TableLayoutPanel (30% - 70%), GroupBox với Anchor (Top, Left, Right) cho TextBox, và Panel với Anchor (Bottom, Right) cho Button.
- `Program.cs`: Entry point khởi chạy ứng dụng.
- `ResponsiveFormApp.csproj`: File cấu hình dự án .NET.

## Cách chạy dự án:
1. Mở thư mục dự án trong Visual Studio / VS Code.
2. Chạy lệnh: `dotnet run`
