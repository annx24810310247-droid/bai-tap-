using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinFormsApp
{
    public class ResponsiveForm : Form
    {
        private TableLayoutPanel mainLayout;
        private GroupBox gbInput;
        private Panel rightPanel;
        private DataGridView dgvData;
        private Button btnSave;
        private Button btnCancel;
        private TextBox txtName;
        private TextBox txtEmail;

        public ResponsiveForm()
        {
            InitializeCustomComponents();
        }

        private void InitializeCustomComponents()
        {
            // 1. Cấu hình Form cơ bản
            this.Text = "Quản Lý Chuẩn Responsive";
            this.Size = new Size(900, 550);
            this.MinimumSize = new Size(700, 450); // Giữ Form không bị thu quá nhỏ gây vỡ giao diện
            this.StartPosition = FormStartPosition.CenterScreen;

            // 2. TableLayoutPanel chính (Dock = Fill, chia 2 cột: 30% và 70%)
            mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 1,
                Padding = new Padding(10)
            };
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70F));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

            // 3. Cột 1 (30%): GroupBox chứa các Control nhập liệu
            gbInput = new GroupBox
            {
                Text = "Thông Tin Chi Tiết",
                Dock = DockStyle.Fill,
                Padding = new Padding(10)
            };

            Label lblName = new Label { Text = "Họ và Tên:", Top = 35, Left = 15, AutoSize = true };
            txtName = new TextBox
            {
                Top = 32,
                Left = 90,
                Width = gbInput.Width - 110,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            Label lblEmail = new Label { Text = "Email:", Top = 75, Left = 15, AutoSize = true };
            txtEmail = new TextBox
            {
                Top = 72,
                Left = 90,
                Width = gbInput.Width - 110,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            gbInput.Controls.AddRange(new Control[] { lblName, txtName, lblEmail, txtEmail });

            // 4. Cột 2 (70%): Panel chứa danh sách & các nút bấm
            rightPanel = new Panel { Dock = DockStyle.Fill };

            dgvData = new DataGridView
            {
                Dock = DockStyle.Top,
                Height = 430,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            btnSave = new Button
            {
                Text = "Lưu",
                Width = 90,
                Height = 32,
                Top = rightPanel.Height - 40,
                Left = rightPanel.Width - 200,
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right
            };

            btnCancel = new Button
            {
                Text = "Hủy",
                Width = 90,
                Height = 32,
                Top = rightPanel.Height - 40,
                Left = rightPanel.Width - 100,
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right
            };

            rightPanel.Controls.AddRange(new Control[] { dgvData, btnSave, btnCancel });

            // 5. Đưa các Control vào TableLayoutPanel
            mainLayout.Controls.Add(gbInput, 0, 0);
            mainLayout.Controls.Add(rightPanel, 1, 0);

            this.Controls.Add(mainLayout);
        }
    }
}
