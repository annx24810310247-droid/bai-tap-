using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinFormsApp
{
    public class CalculatorForm : Form
    {
        private TextBox txtDisplay;
        private double resultValue = 0;
        private string operationPerformed = "";
        private bool isOperationPerformed = false;

        public CalculatorForm()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            // Cấu hình Form Calculator
            this.Text = "Máy Tính WinForms";
            this.Size = new Size(330, 420);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // Màn hình hiển thị kết quả
            txtDisplay = new TextBox
            {
                Top = 20,
                Left = 20,
                Width = 275,
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                TextAlign = HorizontalAlignment.Right,
                ReadOnly = true,
                Text = "0"
            };
            this.Controls.Add(txtDisplay);

            // Bố trí các nút bấm (Layout Matrix)
            string[,] buttons = new string[,]
            {
                { "7", "8", "9", "/" },
                { "4", "5", "6", "*" },
                { "1", "2", "3", "-" },
                { "C", "0", "=", "+" }
            };

            int startX = 20;
            int startY = 80;
            int btnWidth = 60;
            int btnHeight = 60;
            int spacing = 10;

            for (int row = 0; row < 4; row++)
            {
                for (int col = 0; col < 4; col++)
                {
                    string btnText = buttons[row, col];
                    Button btn = new Button
                    {
                        Text = btnText,
                        Size = new Size(btnWidth, btnHeight),
                        Location = new Point(startX + col * (btnWidth + spacing), startY + row * (btnHeight + spacing)),
                        Font = new Font("Segoe UI", 14, FontStyle.Bold)
                    };

                    // Phân loại gán sự kiện theo yêu cầu
                    if (char.IsDigit(btnText[0]))
                    {
                        // 10 nút bấm số từ 0 đến 9 gán chung 1 Event Handler
                        btn.Click += NumberButton_Click;
                    }
                    else if (btnText == "+" || btnText == "-" || btnText == "*" || btnText == "/")
                    {
                        btn.Click += OperatorButton_Click;
                    }
                    else if (btnText == "=")
                    {
                        btn.Click += EqualsButton_Click;
                    }
                    else if (btnText == "C")
                    {
                        btn.Click += ClearButton_Click;
                    }

                    this.Controls.Add(btn);
                }
            }
        }

        // 1. Gán chung 1 Event Handler cho 10 nút bấm số từ 0 đến 9
        private void NumberButton_Click(object sender, EventArgs e)
        {
            if ((txtDisplay.Text == "0") || (isOperationPerformed))
                txtDisplay.Clear();

            isOperationPerformed = false;
            
            // Ép kiểu sender thành Button và nối chuỗi Text vào txtDisplay
            Button btn = (Button)sender;
            txtDisplay.Text += btn.Text;
        }

        // 2. Xử lý các nút phép toán (+, -, *, /)
        private void OperatorButton_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            if (resultValue != 0)
            {
                EqualsButton_Click(null, null);
                operationPerformed = btn.Text;
                isOperationPerformed = true;
            }
            else
            {
                operationPerformed = btn.Text;
                resultValue = double.Parse(txtDisplay.Text);
                isOperationPerformed = true;
            }
        }

        // 3. Xử lý nút Clear (C)
        private void ClearButton_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = "0";
            resultValue = 0;
            operationPerformed = "";
        }

        // 4. Xử lý nút Bằng (=)
        private void EqualsButton_Click(object sender, EventArgs e)
        {
            switch (operationPerformed)
            {
                case "+":
                    txtDisplay.Text = (resultValue + double.Parse(txtDisplay.Text)).ToString();
                    break;
                case "-":
                    txtDisplay.Text = (resultValue - double.Parse(txtDisplay.Text)).ToString();
                    break;
                case "*":
                    txtDisplay.Text = (resultValue * double.Parse(txtDisplay.Text)).ToString();
                    break;
                case "/":
                    double divisor = double.Parse(txtDisplay.Text);
                    if (divisor != 0)
                        txtDisplay.Text = (resultValue / divisor).ToString();
                    else
                        txtDisplay.Text = "Lỗi chia 0";
                    break;
                default:
                    break;
            }
            double.TryParse(txtDisplay.Text, out resultValue);
            operationPerformed = "";
        }
    }
}
