# Dự án WinForms - Máy Tính (Calculator Form)

Dự án C# WinForms thiết kế máy tính bỏ túi gán chung 1 Event Handler cho 10 nút bấm số từ 0 đến 9 thông qua tham số `object sender`.

## Cấu trúc thư mục
- `CalculatorForm.cs`: Chứa giao diện, hàm `NumberButton_Click` dùng chung cho 10 nút số và các logic tính toán `+`, `-`, `*`, `/`, `=`, `C`.
- `Program.cs`: Entry point chạy ứng dụng.
- `CalculatorFormApp.csproj`: File dự án .NET.

## Cách chạy dự án:
1. Mở thư mục dự án trong Visual Studio / VS Code.
2. Chạy lệnh: `dotnet run`
