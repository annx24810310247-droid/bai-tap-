# Dự án WinForms - LoginForm Responsive & Validation

Dự án C# Windows Forms App được thiết lập cho Visual Studio / VS Code.

## Cấu trúc thư mục
- `LoginForm.cs`: Chứa toàn bộ giao diện, xử lý sự kiện Ẩn/Hiện mật khẩu, Validation với ErrorProvider, và cài đặt AcceptButton/CancelButton (Enter/Esc).
- `Program.cs`: Entry point chạy ứng dụng.
- `LoginFormApp.csproj`: File dự án .NET.

## Cách chạy dự án:
1. Mở thư mục dự án trong Visual Studio Code hoặc Visual Studio.
2. Mở Terminal và gõ: `dotnet run`
