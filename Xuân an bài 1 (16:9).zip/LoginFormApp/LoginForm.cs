using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinFormsApp
{
    public class LoginForm : Form
    {
        private TextBox txtUsername;
        private TextBox txtPassword;
        private CheckBox chkShowPassword;
        private Button btnLogin;
        private Button btnExit;
        private ErrorProvider errorProvider;

        public LoginForm()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            // Cấu hình Form cơ bản
            this.Text = "Đăng Nhập Hệ Thống";
            this.Size = new Size(400, 270);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // Khởi tạo ErrorProvider
            errorProvider = new ErrorProvider();

            // Label & TextBox Username
            Label lblUsername = new Label { Text = "Tên đăng nhập:", Top = 30, Left = 25, AutoSize = true };
            txtUsername = new TextBox { Top = 27, Left = 135, Width = 210 };

            // Label & TextBox Password
            Label lblPassword = new Label { Text = "Mật khẩu:", Top = 70, Left = 25, AutoSize = true };
            txtPassword = new TextBox 
            { 
                Top = 67, 
                Left = 135, 
                Width = 210, 
                UseSystemPasswordChar = true 
            };

            // CheckBox Ẩn/Hiện mật khẩu
            chkShowPassword = new CheckBox 
            { 
                Text = "Hiện mật khẩu", 
                Top = 100, 
                Left = 135, 
                AutoSize = true 
            };
            chkShowPassword.CheckedChanged += ChkShowPassword_CheckedChanged;

            // Nút Đăng nhập & Nút Thoát
            btnLogin = new Button { Text = "Đăng nhập", Top = 145, Left = 135, Width = 100, Height = 32 };
            btnExit = new Button { Text = "Thoát", Top = 145, Left = 245, Width = 100, Height = 32 };

            btnLogin.Click += BtnLogin_Click;
            btnExit.Click += (s, e) => this.Close();

            // Gán phím tắt Enter và Esc cho Form
            this.AcceptButton = btnLogin;
            this.CancelButton = btnExit;

            // Thêm Control vào Form
            this.Controls.AddRange(new Control[] { 
                lblUsername, txtUsername, 
                lblPassword, txtPassword, 
                chkShowPassword, btnLogin, btnExit 
            });
        }

        // Xử lý sự kiện Ẩn/Hiện mật khẩu
        private void ChkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = !chkShowPassword.Checked;
        }

        // Xử lý Validate dữ liệu đầu vào khi bấm Đăng nhập
        private void BtnLogin_Click(object sender, EventArgs e)
        {
            errorProvider.Clear(); // Xóa các thông báo lỗi cũ
            bool isValid = true;

            if (string.IsNullOrWhiteSpace(txtUsername.Text))
            {
                errorProvider.SetError(txtUsername, "Vui lòng nhập tên đăng nhập!");
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                errorProvider.SetError(txtPassword, "Vui lòng nhập mật khẩu!");
                isValid = false;
            }

            if (isValid)
            {
                MessageBox.Show("Đăng nhập thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
